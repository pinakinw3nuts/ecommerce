import { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'All Products – MyStore',
  description: 'Browse all our products with filters and search.',
}; 